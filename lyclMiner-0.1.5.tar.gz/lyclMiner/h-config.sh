#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

rm -f $CUSTOM_CONFIG_FILENAME
/hive/custom/${CUSTOM_NAME}/lyclMiner -g $CUSTOM_CONFIG_FILENAME >/dev/null

# Getting detected devices
grep -e 'Device[0-9]' $CUSTOM_CONFIG_FILENAME > /hive/custom/${CUSTOM_NAME}/devices

conf="<Global TerminalColors = \"false\" ExtraNonce = \"true\">
<Connection Url = \"${CUSTOM_URL}\" Username = \"${CUSTOM_TEMPLATE}\" Password = \"${CUSTOM_PASS}\">
"
#conf="-a ${CUSTOM_ALGO} -o ${CUSTOM_URL} -u ${CUSTOM_TEMPLATE} -p ${CUSTOM_PASS} ${CUSTOM_USER_CONFIG}"

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 1


#replace tpl values in whole file
[[ -z %WAL% && -z $ZWAL && -z $DWAL ]] && echo -e "${RED}No WAL address is set${NOCOLOR}"
[[ ! -z $EWAL ]] && conf=$(sed "s/%EWAL%/$EWAL/g" <<< "$conf") #|| echo "${RED}EWAL not set${NOCOLOR}"
[[ ! -z $DWAL ]] && conf=$(sed "s/%DWAL%/$DWAL/g" <<< "$conf") #|| echo "${RED}DWAL not set${NOCOLOR}"
[[ ! -z $ZWAL ]] && conf=$(sed "s/%ZWAL%/$ZWAL/g" <<< "$conf") #|| echo "${RED}ZWAL not set${NOCOLOR}"
[[ ! -z $EMAIL ]] && conf=$(sed "s/%EMAIL%/$EMAIL/g" <<< "$conf")
[[ ! -z $WORKER_NAME ]] && conf=$(sed "s/%WORKER_NAME%/$WORKER_NAME/g" <<< "$conf") #|| echo "${RED}WORKER_NAME not set${NOCOLOR}"

[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && return 1

echo "$conf" > $CUSTOM_CONFIG_FILENAME
echo "" >> $CUSTOM_CONFIG_FILENAME

if [ -z "$CUSTOM_USER_CONFIG" ]; then
	echo "$(cat /hive/custom/$CUSTOM_NAME/devices)" >> $CUSTOM_CONFIG_FILENAME
else

	echo "${CUSTOM_USER_CONFIG}" >> $CUSTOM_CONFIG_FILENAME
fi

rm -f /hive/custom/${CUSTOM_NAME}/devices
